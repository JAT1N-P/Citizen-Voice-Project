
Problem Statement
Add 2 numbers

A practice lab to add two numbers and print output  results. The hint provides the answer. Try entering input values and checking the output.

Important Note:
Ensure that you save your solution before progressing to the next question and  before submitting your answer.

Exercise-1
input:
4
5
output:
9
Exercise-2
input:
7
-3
output:
4

