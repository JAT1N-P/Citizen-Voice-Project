def add(a,b):
    return a+b


num1 = int(input())
num2 = int(input())
ret = add(num1,num2)
print(ret)
