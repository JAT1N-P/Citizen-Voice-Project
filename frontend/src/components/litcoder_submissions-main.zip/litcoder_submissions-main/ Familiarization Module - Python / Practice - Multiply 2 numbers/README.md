
Multiply 2 numbers

A practice lab to multiply 2 numbers and print out the result. The Hint gives the answer. Try entering input values and checking for the output.

Important Note:
Ensure that you save your solution before progressing to the next question and  before submitting your answer.

Exercise-1

input:
4
5
output:
20

Exercise-2

input:
7
-3
output:
-21


