def mul(a,b):
    return a*b

num1 = int(input())
num2 = int(input())
ret = mul(num1,num2)
print(ret)
